--
-- PostgreSQL database dump
--

\restrict 8GNwT1j8Tm9fgNxcYxebYnRtiGYQoS5gszJFEnlTrHzEUhQzZnpC3uavpmM29uc

-- Dumped from database version 14.19 (Homebrew)
-- Dumped by pg_dump version 14.19 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: booking_requests; Type: TABLE; Schema: public; Owner: fixxa_user
--

CREATE TABLE public.booking_requests (
    id integer NOT NULL,
    booking_id integer,
    user_id integer,
    worker_id integer,
    request_type character varying(20) NOT NULL,
    new_date date,
    new_time time without time zone,
    cancellation_reason text,
    status character varying(20) DEFAULT 'pending'::character varying,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    responded_at timestamp without time zone,
    photos text,
    client_rating integer,
    client_comments text,
    completion_notes text,
    CONSTRAINT booking_requests_client_rating_check CHECK (((client_rating >= 1) AND (client_rating <= 5))),
    CONSTRAINT booking_requests_request_type_check CHECK (((request_type)::text = ANY (ARRAY[('reschedule'::character varying)::text, ('cancellation'::character varying)::text, ('completion'::character varying)::text]))),
    CONSTRAINT booking_requests_status_check CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'approved'::character varying, 'rejected'::character varying])::text[])))
);


ALTER TABLE public.booking_requests OWNER TO fixxa_user;

--
-- Name: booking_requests_id_seq; Type: SEQUENCE; Schema: public; Owner: fixxa_user
--

CREATE SEQUENCE public.booking_requests_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.booking_requests_id_seq OWNER TO fixxa_user;

--
-- Name: booking_requests_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: fixxa_user
--

ALTER SEQUENCE public.booking_requests_id_seq OWNED BY public.booking_requests.id;


--
-- Name: bookings; Type: TABLE; Schema: public; Owner: kudadunbetter
--

CREATE TABLE public.bookings (
    id integer NOT NULL,
    user_id bigint NOT NULL,
    worker_id integer NOT NULL,
    booking_date date NOT NULL,
    booking_time time without time zone NOT NULL,
    note text,
    created_at timestamp without time zone DEFAULT now(),
    status text DEFAULT 'pending'::text,
    service text,
    amount numeric(10,2),
    has_review boolean DEFAULT false,
    CONSTRAINT future_booking_date CHECK ((booking_date >= CURRENT_DATE)),
    CONSTRAINT valid_booking_time CHECK (((booking_time >= '06:00:00'::time without time zone) AND (booking_time <= '20:00:00'::time without time zone)))
);


ALTER TABLE public.bookings OWNER TO kudadunbetter;

--
-- Name: bookings_id_seq; Type: SEQUENCE; Schema: public; Owner: kudadunbetter
--

CREATE SEQUENCE public.bookings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.bookings_id_seq OWNER TO kudadunbetter;

--
-- Name: bookings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: kudadunbetter
--

ALTER SEQUENCE public.bookings_id_seq OWNED BY public.bookings.id;


--
-- Name: messages; Type: TABLE; Schema: public; Owner: kudadunbetter
--

CREATE TABLE public.messages (
    id integer NOT NULL,
    client_id bigint NOT NULL,
    professional_id integer NOT NULL,
    content text NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    read_status boolean DEFAULT false,
    sender_type character varying(20) DEFAULT 'client'::character varying
);


ALTER TABLE public.messages OWNER TO kudadunbetter;

--
-- Name: messages_id_seq; Type: SEQUENCE; Schema: public; Owner: kudadunbetter
--

CREATE SEQUENCE public.messages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.messages_id_seq OWNER TO kudadunbetter;

--
-- Name: messages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: kudadunbetter
--

ALTER SEQUENCE public.messages_id_seq OWNED BY public.messages.id;


--
-- Name: reviews; Type: TABLE; Schema: public; Owner: kudadunbetter
--

CREATE TABLE public.reviews (
    id integer NOT NULL,
    client_id integer,
    booking_id integer,
    worker_id integer,
    overall_rating integer NOT NULL,
    quality_rating integer,
    punctuality_rating integer,
    communication_rating integer,
    value_rating integer,
    review_text text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    photos text,
    CONSTRAINT reviews_communication_rating_check CHECK (((communication_rating >= 1) AND (communication_rating <= 5))),
    CONSTRAINT reviews_overall_rating_check CHECK (((overall_rating >= 1) AND (overall_rating <= 5))),
    CONSTRAINT reviews_punctuality_rating_check CHECK (((punctuality_rating >= 1) AND (punctuality_rating <= 5))),
    CONSTRAINT reviews_quality_rating_check CHECK (((quality_rating >= 1) AND (quality_rating <= 5))),
    CONSTRAINT reviews_value_rating_check CHECK (((value_rating >= 1) AND (value_rating <= 5)))
);


ALTER TABLE public.reviews OWNER TO kudadunbetter;

--
-- Name: reviews_id_seq; Type: SEQUENCE; Schema: public; Owner: kudadunbetter
--

CREATE SEQUENCE public.reviews_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.reviews_id_seq OWNER TO kudadunbetter;

--
-- Name: reviews_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: kudadunbetter
--

ALTER SEQUENCE public.reviews_id_seq OWNED BY public.reviews.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: kudadunbetter
--

CREATE TABLE public.users (
    id integer NOT NULL,
    name text NOT NULL,
    email text NOT NULL,
    password text NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    phone character varying(20),
    address text,
    city character varying(100),
    postal_code character varying(20),
    profile_pic text,
    notification_preferences jsonb DEFAULT '{}'::jsonb,
    privacy_preferences jsonb DEFAULT '{}'::jsonb
);


ALTER TABLE public.users OWNER TO kudadunbetter;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: kudadunbetter
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO kudadunbetter;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: kudadunbetter
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: workers; Type: TABLE; Schema: public; Owner: kudadunbetter
--

CREATE TABLE public.workers (
    id integer NOT NULL,
    name text NOT NULL,
    speciality text NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    experience text,
    rating text,
    availability text,
    bio text,
    image text,
    area text,
    email text,
    password text,
    phone character varying(20),
    address text,
    city character varying(100),
    postal_code character varying(20),
    profile_pic text,
    notification_preferences jsonb DEFAULT '{}'::jsonb,
    privacy_preferences jsonb DEFAULT '{}'::jsonb,
    availability_schedule character varying(20) DEFAULT 'both'::character varying,
    is_available boolean DEFAULT true,
    latitude numeric(10,8),
    longitude numeric(11,8),
    service_radius integer DEFAULT 50
);


ALTER TABLE public.workers OWNER TO kudadunbetter;

--
-- Name: workers_id_seq; Type: SEQUENCE; Schema: public; Owner: kudadunbetter
--

CREATE SEQUENCE public.workers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.workers_id_seq OWNER TO kudadunbetter;

--
-- Name: workers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: kudadunbetter
--

ALTER SEQUENCE public.workers_id_seq OWNED BY public.workers.id;


--
-- Name: booking_requests id; Type: DEFAULT; Schema: public; Owner: fixxa_user
--

ALTER TABLE ONLY public.booking_requests ALTER COLUMN id SET DEFAULT nextval('public.booking_requests_id_seq'::regclass);


--
-- Name: bookings id; Type: DEFAULT; Schema: public; Owner: kudadunbetter
--

ALTER TABLE ONLY public.bookings ALTER COLUMN id SET DEFAULT nextval('public.bookings_id_seq'::regclass);


--
-- Name: messages id; Type: DEFAULT; Schema: public; Owner: kudadunbetter
--

ALTER TABLE ONLY public.messages ALTER COLUMN id SET DEFAULT nextval('public.messages_id_seq'::regclass);


--
-- Name: reviews id; Type: DEFAULT; Schema: public; Owner: kudadunbetter
--

ALTER TABLE ONLY public.reviews ALTER COLUMN id SET DEFAULT nextval('public.reviews_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: kudadunbetter
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: workers id; Type: DEFAULT; Schema: public; Owner: kudadunbetter
--

ALTER TABLE ONLY public.workers ALTER COLUMN id SET DEFAULT nextval('public.workers_id_seq'::regclass);


--
-- Data for Name: booking_requests; Type: TABLE DATA; Schema: public; Owner: fixxa_user
--

COPY public.booking_requests (id, booking_id, user_id, worker_id, request_type, new_date, new_time, cancellation_reason, status, created_at, responded_at, photos, client_rating, client_comments, completion_notes) FROM stdin;
\.


--
-- Data for Name: bookings; Type: TABLE DATA; Schema: public; Owner: kudadunbetter
--

COPY public.bookings (id, user_id, worker_id, booking_date, booking_time, note, created_at, status, service, amount, has_review) FROM stdin;
4	1	3	2025-09-30	11:30:00	geyser test book	2025-09-10 19:25:58.875793	Completed	\N	\N	t
\.


--
-- Data for Name: messages; Type: TABLE DATA; Schema: public; Owner: kudadunbetter
--

COPY public.messages (id, client_id, professional_id, content, created_at, read_status, sender_type) FROM stdin;
5	1	1	test2	2025-09-07 19:30:14.512105	f	client
7	1	2	Pravin test	2025-09-07 19:37:26.136726	f	client
8	1	1	hi mahle , i want services	2025-09-07 20:17:46.48178	f	client
9	1	3	hi siya	2025-09-09 11:57:01.544243	f	client
10	1	3	when are you available	2025-09-09 12:22:13.922619	f	client
11	1	3	testing you	2025-09-09 12:22:24.921018	f	client
12	1	3	another test	2025-09-09 12:55:29.395827	f	client
13	1	6	garden test	2025-09-09 13:11:56.057698	f	client
14	1	6	are you available test	2025-09-09 13:12:20.158047	f	client
15	1	1	test	2025-09-09 19:12:56.792492	f	client
16	1	1	test3	2025-09-09 19:21:26.13463	f	client
17	1	1	testing day 1	2025-09-10 14:12:58.752619	f	client
18	1	3	response test	2025-09-12 10:37:10.894591	f	professional
19	1	3	testing	2025-09-12 11:37:38.391997	f	client
20	1	3	got your testing	2025-09-12 11:38:27.563686	f	professional
21	1	3	testing if it is on the correct side	2025-09-12 11:55:52.902509	f	client
22	1	3	looks like it is aligned now	2025-09-12 12:02:11.738328	f	client
23	1	3	response test	2025-09-12 12:11:11.635176	f	professional
24	1	3	test	2025-09-12 12:19:39.563739	f	professional
25	1	3	test	2025-09-12 12:28:20.970416	f	professional
26	1	3	this is a response from the correct side	2025-09-12 12:50:52.769671	f	professional
27	1	3	great test seems fine on my end	2025-09-12 13:36:18.786111	f	client
28	1	3	that's great, its looks goos on my end too	2025-09-12 14:27:21.837287	f	professional
29	1	3	the chat box still works	2025-09-14 20:27:40.66132	f	client
30	1	3	perfect!	2025-09-14 20:28:18.175703	f	professional
31	1	3	still fine?	2025-09-15 16:45:15.674714	f	professional
32	1	3	test	2025-09-16 11:34:46.302799	f	professional
33	1	3	do you do houses test1	2025-09-24 18:16:19.022465	f	client
34	1	3	yes I do I can come next week	2025-09-24 18:19:36.528859	f	professional
\.


--
-- Data for Name: reviews; Type: TABLE DATA; Schema: public; Owner: kudadunbetter
--

COPY public.reviews (id, client_id, booking_id, worker_id, overall_rating, quality_rating, punctuality_rating, communication_rating, value_rating, review_text, created_at, updated_at, photos) FROM stdin;
1	1	4	3	4	4	4	4	4	testing reviews	2025-09-27 12:11:38.50854	2025-09-27 12:11:38.50854	[]
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: kudadunbetter
--

COPY public.users (id, name, email, password, created_at, phone, address, city, postal_code, profile_pic, notification_preferences, privacy_preferences) FROM stdin;
1	test	reg@reg.com	$2b$10$r/3MB6qCCANdC/jTns3UW.mPfE8BFTvz25fAn1hgBQeN81lslXZk.	2025-09-07 18:44:38.130128	\N	\N	\N	\N	\N	{}	{}
2	Test Worker	testworker@work.com	$2b$10$akGEJYwjpibJ0MPZJUkmX.ell6etSdnH8eZj3UJLZRZutTL2nckFi	2025-09-09 14:09:02.370522	\N	\N	\N	\N	\N	{}	{}
\.


--
-- Data for Name: workers; Type: TABLE DATA; Schema: public; Owner: kudadunbetter
--

COPY public.workers (id, name, speciality, created_at, experience, rating, availability, bio, image, area, email, password, phone, address, city, postal_code, profile_pic, notification_preferences, privacy_preferences, availability_schedule, is_available, latitude, longitude, service_radius) FROM stdin;
1	Mahle	Electrician	2025-09-07 19:08:05.038575	7 years	★★★★☆	Weekdays/Weekends	Lorem ipsum dolor sit amet... lfngirgfnids dnglkdngskld lkdbgildsgbds kldgksgnlds kbgdlkgbd dlgkbdklbg d	images/femaleid.webp	Western Cape	\N	\N	\N	\N	\N	\N	\N	{}	{}	both	t	\N	\N	50
2	Pravin	Electrician	2025-09-07 19:08:05.038575	2 years	3	Weekends	Lorem ipsum dolor sit amet...	images/male2.webp	Kwa-Zulu-Natal	\N	\N	\N	\N	\N	\N	\N	{}	{}	both	t	\N	\N	50
4	Victor	Handyman	2025-09-07 19:08:05.038575	5 years	3	Weekdays/Weekends	Lorem ipsum dolor sit amet...	images/indianmanid.jpg	Gauteng	\N	\N	\N	\N	\N	\N	\N	{}	{}	both	t	\N	\N	50
5	Musa	Gardener	2025-09-07 19:08:05.038575	14 years	5	Weekends	Lorem ipsum dolor sit amet...	images/male2.webp	Western Cape	\N	\N	\N	\N	\N	\N	\N	{}	{}	both	t	\N	\N	50
6	Terrisa	Gardener	2025-09-07 19:08:05.038575	2 years	3	Weekdays	Lorem ipsum dolor sit amet...	images/femaleid.webp	Kwa-Zulu-Natal	\N	\N	\N	\N	\N	\N	\N	{}	{}	both	t	\N	\N	50
7	Jaco	Plumber	2025-09-07 19:08:05.038575	10 years	4	Weekends	Lorem ipsum dolor sit amet...	images/indianmanid.jpg	North West	\N	\N	\N	\N	\N	\N	\N	{}	{}	both	t	\N	\N	50
9	Work Test	Plumber	2025-09-09 18:32:24.914714	\N	\N	\N	\N	\N	\N	work@work.com	$2b$10$lfuwEUykI8vdxSIqWH0UeOmKSQJSAYhnZOTtVRmB7n2eYBB2SpP7W	\N	\N	\N	\N	\N	{}	{}	both	t	\N	\N	50
3	Siya	Painter	2025-09-07 19:08:05.038575	5 years	4	Weekends	Lorem ipsum dolor sit amet lorjdsnfbkdjlgbkldfb kjdgbjdfbvjkfd kjdfgbjdbdjs jsdbgdfsjgb jkgbgkldsjg sdm gsdjgbdgbdgbdklg	images/indianmanid.jpg	Gauteng	siya@example.com	$2b$10$BtelNpOa/GoXihq1/acsTOLGSfIg/n674UVOAilhgSS4YF/OGZeuu	\N	\N	\N	\N	\N	{}	{}	both	t	\N	\N	50
\.


--
-- Name: booking_requests_id_seq; Type: SEQUENCE SET; Schema: public; Owner: fixxa_user
--

SELECT pg_catalog.setval('public.booking_requests_id_seq', 1, false);


--
-- Name: bookings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: kudadunbetter
--

SELECT pg_catalog.setval('public.bookings_id_seq', 5, true);


--
-- Name: messages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: kudadunbetter
--

SELECT pg_catalog.setval('public.messages_id_seq', 34, true);


--
-- Name: reviews_id_seq; Type: SEQUENCE SET; Schema: public; Owner: kudadunbetter
--

SELECT pg_catalog.setval('public.reviews_id_seq', 1, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: kudadunbetter
--

SELECT pg_catalog.setval('public.users_id_seq', 2, true);


--
-- Name: workers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: kudadunbetter
--

SELECT pg_catalog.setval('public.workers_id_seq', 9, true);


--
-- Name: booking_requests booking_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: fixxa_user
--

ALTER TABLE ONLY public.booking_requests
    ADD CONSTRAINT booking_requests_pkey PRIMARY KEY (id);


--
-- Name: bookings bookings_pkey; Type: CONSTRAINT; Schema: public; Owner: kudadunbetter
--

ALTER TABLE ONLY public.bookings
    ADD CONSTRAINT bookings_pkey PRIMARY KEY (id);


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: public; Owner: kudadunbetter
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id);


--
-- Name: reviews reviews_pkey; Type: CONSTRAINT; Schema: public; Owner: kudadunbetter
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT reviews_pkey PRIMARY KEY (id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: kudadunbetter
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: kudadunbetter
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: workers workers_email_key; Type: CONSTRAINT; Schema: public; Owner: kudadunbetter
--

ALTER TABLE ONLY public.workers
    ADD CONSTRAINT workers_email_key UNIQUE (email);


--
-- Name: workers workers_pkey; Type: CONSTRAINT; Schema: public; Owner: kudadunbetter
--

ALTER TABLE ONLY public.workers
    ADD CONSTRAINT workers_pkey PRIMARY KEY (id);


--
-- Name: idx_booking_requests_status; Type: INDEX; Schema: public; Owner: fixxa_user
--

CREATE INDEX idx_booking_requests_status ON public.booking_requests USING btree (status);


--
-- Name: idx_booking_requests_type; Type: INDEX; Schema: public; Owner: fixxa_user
--

CREATE INDEX idx_booking_requests_type ON public.booking_requests USING btree (request_type);


--
-- Name: idx_bookings_status; Type: INDEX; Schema: public; Owner: kudadunbetter
--

CREATE INDEX idx_bookings_status ON public.bookings USING btree (status);


--
-- Name: idx_reviews_booking; Type: INDEX; Schema: public; Owner: kudadunbetter
--

CREATE INDEX idx_reviews_booking ON public.reviews USING btree (booking_id);


--
-- Name: idx_reviews_client; Type: INDEX; Schema: public; Owner: kudadunbetter
--

CREATE INDEX idx_reviews_client ON public.reviews USING btree (client_id);


--
-- Name: idx_reviews_worker; Type: INDEX; Schema: public; Owner: kudadunbetter
--

CREATE INDEX idx_reviews_worker ON public.reviews USING btree (worker_id);


--
-- Name: idx_unique_booking; Type: INDEX; Schema: public; Owner: kudadunbetter
--

CREATE UNIQUE INDEX idx_unique_booking ON public.bookings USING btree (worker_id, booking_date, booking_time) WHERE (status <> ALL (ARRAY['Cancelled'::text, 'Completed'::text]));


--
-- Name: booking_requests booking_requests_booking_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fixxa_user
--

ALTER TABLE ONLY public.booking_requests
    ADD CONSTRAINT booking_requests_booking_id_fkey FOREIGN KEY (booking_id) REFERENCES public.bookings(id) ON DELETE CASCADE;


--
-- Name: booking_requests booking_requests_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fixxa_user
--

ALTER TABLE ONLY public.booking_requests
    ADD CONSTRAINT booking_requests_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: booking_requests booking_requests_worker_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fixxa_user
--

ALTER TABLE ONLY public.booking_requests
    ADD CONSTRAINT booking_requests_worker_id_fkey FOREIGN KEY (worker_id) REFERENCES public.workers(id) ON DELETE CASCADE;


--
-- Name: bookings bookings_worker_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kudadunbetter
--

ALTER TABLE ONLY public.bookings
    ADD CONSTRAINT bookings_worker_id_fkey FOREIGN KEY (worker_id) REFERENCES public.workers(id) ON DELETE CASCADE;


--
-- Name: messages messages_professional_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kudadunbetter
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_professional_id_fkey FOREIGN KEY (professional_id) REFERENCES public.workers(id) ON DELETE CASCADE;


--
-- Name: reviews reviews_booking_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kudadunbetter
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT reviews_booking_id_fkey FOREIGN KEY (booking_id) REFERENCES public.bookings(id);


--
-- Name: reviews reviews_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kudadunbetter
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT reviews_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.users(id);


--
-- Name: reviews reviews_worker_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kudadunbetter
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT reviews_worker_id_fkey FOREIGN KEY (worker_id) REFERENCES public.workers(id);


--
-- Name: TABLE bookings; Type: ACL; Schema: public; Owner: kudadunbetter
--

GRANT ALL ON TABLE public.bookings TO fixxa_user;


--
-- Name: SEQUENCE bookings_id_seq; Type: ACL; Schema: public; Owner: kudadunbetter
--

GRANT ALL ON SEQUENCE public.bookings_id_seq TO fixxa_user;


--
-- Name: TABLE messages; Type: ACL; Schema: public; Owner: kudadunbetter
--

GRANT ALL ON TABLE public.messages TO fixxa_user;


--
-- Name: SEQUENCE messages_id_seq; Type: ACL; Schema: public; Owner: kudadunbetter
--

GRANT ALL ON SEQUENCE public.messages_id_seq TO fixxa_user;


--
-- Name: TABLE reviews; Type: ACL; Schema: public; Owner: kudadunbetter
--

GRANT ALL ON TABLE public.reviews TO fixxa_user;


--
-- Name: SEQUENCE reviews_id_seq; Type: ACL; Schema: public; Owner: kudadunbetter
--

GRANT ALL ON SEQUENCE public.reviews_id_seq TO fixxa_user;


--
-- Name: TABLE users; Type: ACL; Schema: public; Owner: kudadunbetter
--

GRANT ALL ON TABLE public.users TO fixxa_user;


--
-- Name: SEQUENCE users_id_seq; Type: ACL; Schema: public; Owner: kudadunbetter
--

GRANT ALL ON SEQUENCE public.users_id_seq TO fixxa_user;


--
-- Name: TABLE workers; Type: ACL; Schema: public; Owner: kudadunbetter
--

GRANT ALL ON TABLE public.workers TO fixxa_user;


--
-- Name: SEQUENCE workers_id_seq; Type: ACL; Schema: public; Owner: kudadunbetter
--

GRANT ALL ON SEQUENCE public.workers_id_seq TO fixxa_user;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: kudadunbetter
--

ALTER DEFAULT PRIVILEGES FOR ROLE kudadunbetter IN SCHEMA public GRANT ALL ON TABLES  TO fixxa_user;


--
-- PostgreSQL database dump complete
--

\unrestrict 8GNwT1j8Tm9fgNxcYxebYnRtiGYQoS5gszJFEnlTrHzEUhQzZnpC3uavpmM29uc

